
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class DBUtils {
    static public Connection getConnection(){
        Connection koneksi = null;
        try {
            koneksi = DriverManager.getConnection("jdbc:mysql://localhost/shop","root","");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Koneksi ke database GAGAl\n"+e, "Informasi", JOptionPane.WARNING_MESSAGE);
        }
        return koneksi;
    }
}
