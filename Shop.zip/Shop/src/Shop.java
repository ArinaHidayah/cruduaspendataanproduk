import java.awt.print.PrinterException;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Shop extends javax.swing.JFrame {
    private DefaultTableModel DftTblModel_produk;
    public Shop() {
        initComponents();
        initData();
    }
    
    public boolean isValidInput(){
        boolean valid = true;
        if(txtKode.getText().toString().isEmpty()){
            JOptionPane.showMessageDialog(null, "Kode produk tidak boleh kosong", "Informasi", JOptionPane.WARNING_MESSAGE);
            valid=false;
        }
        if(txtNama.getText().toString().isEmpty()){
            JOptionPane.showMessageDialog(null, "Nama produk tidak boleh kosong", "Informasi", JOptionPane.WARNING_MESSAGE);
            valid=false;
        }
        if(txtHarga.getText().toString().isEmpty()){
            JOptionPane.showMessageDialog(null, "Harga tidak boleh kosong", "Informasi", JOptionPane.WARNING_MESSAGE);
            valid=false;
        }
        if(txtStok.getText().toString().isEmpty()){
            JOptionPane.showMessageDialog(null, "Stok tidak boleh kosong", "Informasi", JOptionPane.WARNING_MESSAGE);
            valid=false;
        }
        return valid;
    }
    
    public void initData() {
        DftTblModel_produk = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
               return false;
            }
        };
        DftTblModel_produk.addColumn("Kode Barang");
        DftTblModel_produk.addColumn("Nama Barang");
        DftTblModel_produk.addColumn("Satuan");
        DftTblModel_produk.addColumn("Harga");
        DftTblModel_produk.addColumn("Stok");
        DftTblModel_produk.addColumn("Create Date");
        tblProduk.setModel(DftTblModel_produk);
        try {
            Connection conn=DBUtils.getConnection();
            Statement stat = (Statement) conn.createStatement();
            ResultSet res = stat.executeQuery("SELECT * FROM produk");
            while (res.next()) {
                Produk produk = new Produk(
                        res.getString("KodeProduk"),
                        res.getString("NamaProduk"),
                        res.getString("Satuan"),
                        res.getInt("Harga"),
                        res.getInt("Stok"),
                        res.getTimestamp("CreateDate")
                );
                DftTblModel_produk.addRow(produk.getObject());
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    private void reset(){
        txtKode.setText(null);
        txtKode.setEnabled(false);
        txtNama.setText(null);
        txtNama.setEnabled(false);
        cbbSatuan.setSelectedIndex(0);
        cbbSatuan.setEnabled(false);
        txtHarga.setText(null);
        txtHarga.setEnabled(false);
        txtStok.setText(null);
        txtStok.setEnabled(false);
        btnSave.setEnabled(false);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
        btnCancel.setEnabled(false);
    }
    
    Produk generateProduk(){
        return new Produk(txtKode.getText(), txtNama.getText(), cbbSatuan.getSelectedItem().toString(), Integer.parseInt(txtHarga.getText()), Integer.parseInt(txtStok.getText()));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProduk = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txtKode = new javax.swing.JTextField();
        txtNama = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtHarga = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtStok = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btnAddNew = new javax.swing.JButton();
        btnPrint = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        cbbSatuan = new javax.swing.JComboBox<String>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Data Produk");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblProduk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tblProduk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblProdukMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblProduk);

        jLabel2.setText("Kode Produk");

        txtKode.setEnabled(false);

        txtNama.setEnabled(false);

        jLabel3.setText("Nama");

        jLabel4.setText("Satuan");

        txtHarga.setEnabled(false);
        txtHarga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHargaKeyTyped(evt);
            }
        });

        jLabel5.setText("Harga");

        txtStok.setEnabled(false);
        txtStok.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtStokKeyTyped(evt);
            }
        });

        jLabel6.setText("Stok");

        btnAddNew.setText("AddNew");
        btnAddNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNewActionPerformed(evt);
            }
        });

        btnPrint.setText("Print");
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });

        btnSave.setText("Save");
        btnSave.setEnabled(false);
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        btnUpdate.setText("Update");
        btnUpdate.setEnabled(false);
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete");
        btnDelete.setEnabled(false);
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancel");
        btnCancel.setEnabled(false);
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        cbbSatuan.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Pcs", "Box", "Kg" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtKode, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(90, 90, 90)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnAddNew)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnPrint))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSave)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnUpdate)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnDelete)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCancel))))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(cbbSatuan, javax.swing.GroupLayout.Alignment.TRAILING, 0, 306, Short.MAX_VALUE)
                                .addComponent(txtHarga, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txtStok, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 902, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtKode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cbbSatuan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtStok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAddNew)
                            .addComponent(btnPrint))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSave)
                            .addComponent(btnUpdate)
                            .addComponent(btnDelete)
                            .addComponent(btnCancel))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblProdukMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblProdukMouseClicked
        int baris = tblProduk.getSelectedRow();
        txtKode.setText(DftTblModel_produk.getValueAt(baris, 0).toString());
        txtKode.setEnabled(false);
        txtNama.setText(DftTblModel_produk.getValueAt(baris, 1).toString());
        txtNama.setEnabled(true);
        cbbSatuan.setSelectedItem(DftTblModel_produk.getValueAt(baris, 2).toString());
        cbbSatuan.setEnabled(true);
        txtHarga.setText(DftTblModel_produk.getValueAt(baris, 3).toString());
        txtHarga.setEnabled(true);
        txtStok.setText(DftTblModel_produk.getValueAt(baris, 4).toString());
        txtStok.setEnabled(true);
        btnSave.setEnabled(false);
        btnUpdate.setEnabled(true);
        btnDelete.setEnabled(true);
        btnCancel.setEnabled(true);
    }//GEN-LAST:event_tblProdukMouseClicked

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        reset();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnAddNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNewActionPerformed
        txtKode.setText(null);
        txtKode.setEnabled(true);
        txtNama.setText(null);
        txtNama.setEnabled(true);
        cbbSatuan.setSelectedIndex(0);
        cbbSatuan.setEnabled(true);
        txtHarga.setText(null);
        txtHarga.setEnabled(true);
        txtStok.setText(null);
        txtStok.setEnabled(true);
        btnSave.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
        btnCancel.setEnabled(false);
    }//GEN-LAST:event_btnAddNewActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed
        try {
            tblProduk.print();
        } catch (PrinterException ex) {
            Logger.getLogger(Shop.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnPrintActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        if(isValidInput()){
            try {
                Produk produk = generateProduk();
                Connection conn=DBUtils.getConnection();
                Statement stat = conn.createStatement();
                ResultSet res = stat.executeQuery(produk.getProdukQuery());
                if(res.next()){
                    JOptionPane.showMessageDialog(null, "Kode Produk telah ada pada Database", "Informasi", JOptionPane.WARNING_MESSAGE);
                    initData();
                    return;
                }
                PreparedStatement Pstat = (PreparedStatement) conn.prepareStatement(produk.getSaveQuery());
                Pstat.execute();
                JOptionPane.showMessageDialog(null, "Menyimpan Data Berhasil", "Informasi", JOptionPane.WARNING_MESSAGE);
                conn.close();
                initData();
                reset();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Menyimpan Data Gagal\n"+e, "Informasi", JOptionPane.WARNING_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        int baris = tblProduk.getSelectedRow();
        int confirm = JOptionPane.showConfirmDialog(null, "Yakin ingin menghapus produk dengan kode "+
                DftTblModel_produk.getValueAt(baris, 0).toString()
                +"?", 
                "Confirmation Dialog", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE);
        if (confirm == 0) {
            try {
                Connection conn=DBUtils.getConnection();
                PreparedStatement stmt = conn.prepareStatement(generateProduk().getDeleteQuery());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "Hapus Data Berhasil", "Information", JOptionPane.INFORMATION_MESSAGE);
                initData();
                reset();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Hapus Data Gagal\n" + e.getMessage(), "Information", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        int baris = tblProduk.getSelectedRow();
        if(isValidInput()){
            try {
                Connection conn = DBUtils.getConnection();
                PreparedStatement stat = (PreparedStatement) conn.prepareStatement(generateProduk().getUpdateQuery());
                stat.execute();
                JOptionPane.showMessageDialog(null, "Mengubah Data Berhasil", "Informasi", JOptionPane.WARNING_MESSAGE);
                conn.close();
                initData();
                reset();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Mengubah Data Gagal\n"+e, "Informasi", JOptionPane.WARNING_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void txtHargaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtHargaKeyTyped
        try{
            Integer.parseInt(txtHarga.getText()+evt.getKeyChar());
        }catch(Exception e){
            evt.consume();
        }
    }//GEN-LAST:event_txtHargaKeyTyped

    private void txtStokKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtStokKeyTyped
        try{
            Integer.parseInt(txtStok.getText()+evt.getKeyChar());
        }catch(Exception e){
            evt.consume();
        }
    }//GEN-LAST:event_txtStokKeyTyped

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Shop().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddNew;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cbbSatuan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblProduk;
    private javax.swing.JTextField txtHarga;
    private javax.swing.JTextField txtKode;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtStok;
    // End of variables declaration//GEN-END:variables
}
