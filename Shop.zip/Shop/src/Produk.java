
import java.sql.Timestamp;

public class Produk {
    String kode, nama, satuan;
    int harga, stok;
    Timestamp createDate;

    public Produk(String kode, String nama, String satuan, int harga, int stok, Timestamp createDate) {
        this.kode = kode;
        this.nama = nama;
        this.satuan = satuan;
        this.harga = harga;
        this.stok = stok;
        this.createDate = createDate;
    }

    public Produk(String kode, String nama, String satuan, int harga, int stok) {
        this.kode = kode;
        this.nama = nama;
        this.satuan = satuan;
        this.harga = harga;
        this.stok = stok;
    }
    
    public String getProdukQuery(){
        return "SELECT * FROM produk WHERE KodeProduk = '"+kode+"'";
    }
    
    public String getSaveQuery(){
        return "INSERT INTO produk "
                + "values(" 
                + "'"+kode+"', "
                + "'"+nama+"', "
                + "'"+satuan+"', "
                + harga+","
                + stok+",NOW())";
    }
    
    public String getUpdateQuery(){
        return "UPDATE produk SET "+
                        "NamaProduk = '"+nama+"', "+
                        "Satuan = '"+satuan+"', "+
                        "Harga = "+harga+", "+
                        "Stok = "+stok+
                        " WHERE KodeProduk = '"+kode+"'";
    }
    
    public String getDeleteQuery(){
        return "DELETE FROM produk WHERE KodeProduk = '" + kode+"'";
    }
    
    Object[] getObject(){
        return new Object[]{kode,nama,satuan,harga,stok,createDate};
    }
}
